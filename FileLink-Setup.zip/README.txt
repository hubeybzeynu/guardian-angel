FileLink Setup

1. Extract this zip.
2. Open FileLink-Setup.exe and follow the steps (documents, folder, options). It downloads FileLink and the command line (about 90 MB) and checks them before installing.
3. Windows asks for administrator permission once, to install into Program Files and add FileLink to PATH.
4. Open a new Command Prompt or PowerShell and type: filelinkcli  (needs Node.js 18+)

